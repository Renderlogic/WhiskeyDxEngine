class ApplicationController < ActionController::API
  include ActionController::Serialization
end
