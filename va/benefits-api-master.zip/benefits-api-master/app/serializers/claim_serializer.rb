class ClaimSerializer < ActiveModel::Serializer
  attributes :id
end
