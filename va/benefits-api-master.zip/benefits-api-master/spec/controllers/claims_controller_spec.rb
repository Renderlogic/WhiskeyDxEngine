require "rails_helper"

RSpec.describe ClaimsController, type: :controller do
end
