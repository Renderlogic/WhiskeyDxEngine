VA_Data_Assets_VBA
==================

The repository is controlled by the Department of Veterans Affairs (VA) Office of Information Technology (OI&T) Open Data group. All data assets that are in this repository have been reviewed and approved by the VA Privacy Officer associated with the Veterans Benefits Administration. They have been posted at the request of the relevant VA office. Questions or comments can be addressed by Michael Miti-Kavuma (michael.miti-kavuma@va.gov).
